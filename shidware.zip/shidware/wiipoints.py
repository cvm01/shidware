from operator import truediv


print("How much wii points? numbers only")
amountToGen = input()
gen = 0
import time

print("Generating... (Please wait)")
time.sleep(5)
print("Whats your ip adress??")

ipadress2 = input()

print("sending wii points to your console!")
time.sleep(3)
print("Now you have" + str(amountToGen) + " Wii points!")